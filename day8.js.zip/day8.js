console.log("sdf"); //for output
console.log(3+4-20);


//variables

var x=35;
var y=35.333;
var y ="fewr";
var n =true;

console.log(x);
console.log("x");


//dictionary

/*
var d ={
  "name":"prabh",
  "gpa":3.0,
  "id": "c0730124",
  "cource":[
            "mad123",
            "mad456",
            "mad657"
            ]
  "friend":{
            "name":"kamal",
            "pet":"dog",
            "id": "c0730124"
    
  }
}
\

console.log(d);
console.log(d.name);//to get output of particular key
console.log(d["name"]); //another way of doing same
console.log(d.cource[1]);

//console.log(d.friend.pet);
console.log(d.["friend"]["pet"]);
*/


var e = {
  "name":"pritesh",
  "id" : "C093491",
  "friend": {
            "name": "marcos",
            "pets": ["dog", "cat"],
            "grades" : {
              "4114":"A+",
              "4124":"C-"
    }
  },
  "food": {
          "pizza": {
            "1":"tomatos",
            "2":"chicken",
            "3":"salad"
    },
    "brunch":[83, 23, 14, 55]
  }
}

console.log(e.food.brunch[2]);
console.log(e.friend.pets[1]);
console.log(e["friend"]["grades"]["4114"]);
console.log(e["food"]["pizza"]["2"]);
console.log(e.food.pizza["3"]);

console.log(4*(90/100)+4*(65/100)/8);




var gpa = {
  "A+":90,
  "C-":65
}

console.log(
  (gpa[e.friend.grades["4114"]]
  +
  gpa[e.friend.grades["4124"]]
  )
  /2);
  
  
  
  
  //LOOPS
  
  var p =["abc","def","ijk","lmn"];
  p.forEach(function(x){
    console.log("x");
  });
  
  
  function abc(){
    return 2;
  }
  
  var p = abc();
  console.log(p);
  
  
  
  var a =["apple","banana","apple"];
  function palindrome(a){
    return a;
  }
    /*
    if (a[0] == a[2]){
      console.log("yes");
    }
    else{
      console.log('no');
    }
  */
  
  
  /*
  if (var i=0;i<a.length;i++){
     if (a[0];a.length;a++){
       console.log("yes");
     }
     elseif(a.length-1;a.length;i--){
       console.log("no");
     }
    
  }
  
  
  
   if (a[0] == a[a.length-1]){
      console.log("yes");
    }
    else{
      console.log('no');
    }
  
   */
   var len=a.length;
   
 console.log(a);
 
 var check = false;
  
 for (var i=0;i<len/2;i++){ 
  if(a[i]==a[len-(i+1)]){
       check=true;
       continue;
     }
    else{
        check=false;
        break;
    }
 }