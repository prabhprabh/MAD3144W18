var questionBank =
[
 {
   "question": "Who's my favorite Avenger?",
   "answers": {
     "a":"Iron Man",
     "b":"Thor"
   },
   "correct":"b",
 },
 {
   "question": "What's word do I use the most?",
   "answers": {
     "a":"Awesome!",
     "b":"Bakwas!"
   },
   "correct":"b",
 },
 {
   "question": "What's my favorite programming language?",
   "answers": {
     "a":"Python",
     "b":"Swift"
   },
   "correct":"a",
 }
]
